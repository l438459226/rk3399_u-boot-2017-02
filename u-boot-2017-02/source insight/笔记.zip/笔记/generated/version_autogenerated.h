#define PLAIN_VERSION "2017.02-RK3399-06"
#define U_BOOT_VERSION "U-Boot " PLAIN_VERSION
#define CC_VERSION_STRING "aarch64-linux-android-gcc (GCC) 4.9.x-google 20140827 (prerelease)"
#define LD_VERSION_STRING "GNU ld (GNU Binutils) 2.24.90"
